package util;

public class Constants {
    public static final String BACKEND_URL = "http://localhost:3000";
}
