package aplus;

// import software.amazon.spapi.api.uploads.v2020_11_01.UploadsApi;
// import util.Constants;
import util.Recipe;
// import util.Constants;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;

/**
 * Uploading Images to A+ Content is a 4 step process:
 * - Calculate the MD5 for the image.
 * - Call the createUploadDestinationForResource
 * - Refactor the url in the createUploadDestinationForResource response passing
 * the query params to form data
 * - PUT the image in the refactored URL
 */

public class UploadImage extends Recipe {

    // private final UploadsApi UploadsApi = new UploadsApi.Builder()
    // .lwaAuthorizationCredentials(lwaCredentials)
    // .endpoint(Constants.BACKEND_URL)
    // .build();

    /*
     * TODO: Create a dedicated method for each step in your use case. The
     * start-method should be used to orchestrate the
     * steps accordingly and add any necessary code to glue the steps together.
     */
    @Override
    protected void start() {
        File image = new File("teste.png");
        String md5 = calculateMd5(image);
        System.out.println(md5);

    }

    private String calculateMd5(File file) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            byte[] buffer = new byte[8192];
            int bytesRead;

            while ((bytesRead = bis.read(buffer)) != -1) {
                md.update(buffer, 0, bytesRead);
            }

            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b & 0xff));
            }

            bis.close();
            fis.close();
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Couldn't Calculate MD5 for file", e);
        }
    }
}
