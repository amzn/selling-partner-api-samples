<?php

namespace Src\util;

class Constants
{
    const string BACKEND_URL = "http://localhost:3000";
}
